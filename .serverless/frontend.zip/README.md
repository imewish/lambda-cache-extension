# lambda-cache-extension
AWS Lambda extension to cache DynamoDb,S3,AppConfig Calls
